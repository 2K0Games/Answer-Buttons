﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.Advertisements;


public class SwitchScenes : MonoBehaviour {
   
    public void IfYesPressed()
    {
        SceneManager.LoadScene("Yes");
    }

    public void IfYessssssssPressed()
    {
        SceneManager.LoadScene("Yessssss");
    }

    public void IfMaybePressed()
    {
        SceneManager.LoadScene("Maybe");
    }
     public void IfNoPressed()
     {
         SceneManager.LoadScene("No");
     }
    public void IfNooooooooPressed()
    {
        SceneManager.LoadScene("Nooooo");
    }

    public void IfBackPressed()
    {
        Advertisement.Show();
        SceneManager.LoadScene("Button Game");
    }
}
